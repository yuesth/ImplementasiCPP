
package tugasiipro;
import java.util.Random;
import java.text.DecimalFormat;

public class MathRandom {
    static Random r=new Random();
    static TugasIIpro t=new TugasIIpro();
    static double angka;
    static Double []x=new Double[100];
    static DecimalFormat dd=new DecimalFormat("#.##");
   
    
    public  void random_array(int msuk){
        
        for(int i=0;i<msuk;i++){
        angka=r.nextDouble();
        System.out.println(dd.format(angka)+", ");
        x[i]=angka;
        } 
    }
    
    
     
    
    
}
