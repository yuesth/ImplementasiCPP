
package tugasiipro;
import java.util.Scanner;
import java.util.Random;



public class TugasIIpro {
    static Scanner sc=new Scanner(System.in);
    static Random rr=new Random();
    static MathRandom r=new MathRandom();
    static sorting so=new sorting();
    static binsearch bs=new binsearch();
    static int datasize,masuk; 
    
    
    static void bnykdata(){
    System.out.println("Masukkan banyak nilai IPK:");
       masuk=sc.nextInt();
    }
    
   
    public static void main(String[] args) {
     System.out.println("*Mencari data IPK dalam suatu array secara random**");
     
     bnykdata();
     r.random_array(masuk);
     so.selection_sort();
     bs.data_cari();
     bs.bin_search();
     
    }   
     
}
     
     
     
     
     
    
    

