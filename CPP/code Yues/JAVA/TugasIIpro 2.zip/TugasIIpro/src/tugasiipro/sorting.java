
package tugasiipro;
import java.text.DecimalFormat;


public class sorting {
    static double temp;
    static DecimalFormat de=new DecimalFormat("#.##");
    
    public void selection_sort(){
      for(int i=0;i<(TugasIIpro.masuk-1);i++){
          int min=i;
          for(int j=i+1;j<TugasIIpro.masuk;j++){
              if(MathRandom.x[j]<MathRandom.x[min])
              {
                  min=j;
              }
          }
          temp=MathRandom.x[i];
          MathRandom.x[i]=MathRandom.x[min];
          MathRandom.x[min]=temp; 
      }
     
          System.out.println("*Data sesudah diurut*");
        for(int k=0;k<TugasIIpro.masuk;k++){
            System.out.println("Data array ke"+(k+1)+":"+de.format(MathRandom.x[k])+" ");
        }
       
      
    
    }
}

    

