
package tugasiipro;
import java.util.Scanner;

    public class binsearch {
    static Scanner sca = new Scanner(System.in);
    static double f;
    
    public  void data_cari(){
        System.out.print("Data yang dicari:");
         f=sca.nextDouble();
        
    }
    
    public  void bin_search(){
        int aw=0,ak=(TugasIIpro.masuk-1);
        int te=(aw+ak)/2;boolean b=false;
        while(aw<=ak && b ){
            if(MathRandom.x[te]<f){
               aw=te+1; 
            }
            else if(MathRandom.x[te]==f){
                b=true;
            }
            else{
                ak=te-1;
            }
        }
        if(b){
            System.out.println("Tidak Ditemukan");
        }
        else{
            System.out.println("Data ditemukan "+"di array ke-"+te);
        }
    }
}
