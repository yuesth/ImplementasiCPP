
package projecttask3;

 class Node{
     int data;
     Node next;
 }
 
class nodedanlist {
     Node head;
     Node tail;
     
     public boolean isEmpty(){
         return (head==null);
     }
     
     
    void addLast(Node input){
		if (isEmpty()){	//Jika linked list masih kosong,
			head = input;	//maka head dan tail sama dengan node input
			tail = input;
		}
		else {
			tail.next = input;	//Jika linked list sudah berisi,
			tail = input;	//maka input akan di belakang dan menjadi tail
		}
	}
     
    public void insertAfter(int key,Node input){
        Node temp=head;
        do{
            if(temp.data==key){
                input.next=temp.next;
                temp.next=input;break;
            }
           temp=temp.next;
        }
        while(temp!=null);
    }
    
    
    void printNode(){
  		Node temp=head;  
  		while (temp != null){
   			System.out.print(temp.data+" ");
   			temp = temp.next;
  		}
                System.out.println();
    }

}
