/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecttask3;
import java.util.Scanner;
import java.util.Random;

public class Projecttask3 {

    
    public static void main(String[] args) {
        nodedanlist nl=new nodedanlist();
        Scanner sc=new Scanner(System.in);
       
        Random r=new Random();
        
        System.out.print("Masukkan banyak data:");
        int in=sc.nextInt();
        
        for(int i=1;i<=in;i++){
          int rd=r.nextInt(100)+1; 
          Node n=new Node();
          n.data=rd;
          n.next=null;
          nl.addLast(n);
          System.out.print(rd+" ");
        }
        System.out.println();
        nl.printNode();
        
        System.out.println();
        
        System.out.print("Masukkan tambahan data setelah nilai :");
        int inp=sc.nextInt();
        System.out.print("banyak data yang ditambahkan:");
        int tmb=sc.nextInt();
        for(int l=1;l<=tmb;l++){
            int rdm=r.nextInt(100)+1;
            Node m=new Node();
            m.data=rdm;
            m.next=null;
          nl.insertAfter(inp,m);
        }
         nl.printNode();
        
    }
    
}

