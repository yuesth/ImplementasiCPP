
package tugaspraki;


public class statushotel {
    protected String nama;
    protected int kamarke;
    protected String status;
    
    public statushotel(){
        for(int i=0;i<15;i++){
        status="kosong";kamarke=0;
        System.out.println("kamar ke"+(i+1)+":"+status);
        kamarke++;
        }
    }
    
    public statushotel(String nm, int kamarkee){
        kamarke=kamarkee;
        nama=nm;
        status="terisi";
        
    }
    
    public int getKamar(){
        return kamarke;
    }
    
    public String getStatus(){
        return status;
    }
    
    public String getNama(){
        return nama;
    }
}
