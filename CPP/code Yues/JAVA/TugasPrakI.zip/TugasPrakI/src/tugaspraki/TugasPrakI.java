/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugaspraki;
import java.util.Scanner;

public class TugasPrakI {

    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Masukkan nama penginap:");
        String nma=sc.next();
        System.out.print("Pilih kamar:");
        int kamr=sc.nextInt();
        System.out.println();
        statushotel sh=new statushotel();
        System.out.println();
        statushotel sh1=new statushotel(nma,kamr);
    System.out.println("Kamar :"+sh1.getKamar()+" ,status:"+sh1.getStatus()+" ,atas nama:"+sh1.getNama());
        
    }
    
}
