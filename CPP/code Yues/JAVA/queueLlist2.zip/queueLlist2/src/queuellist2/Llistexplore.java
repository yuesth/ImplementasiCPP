
package queuellist2;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Iterator;

public class Llistexplore {
    Scanner sc=new Scanner(System.in);
    LinkedList<CharLib> Queuell=new LinkedList<>(); static int batas;
    LinkedList<CharLib> Queuelkiri = new LinkedList<>();
    LinkedList<CharLib> Queuelkanan = new LinkedList<>();
    
    public void masukLinkedList(){
        System.out.print("Banyak data Q: "); batas=sc.nextInt();
        for(int i=0;i<batas;i++){
           System.out.print("Karakter ke-"+(i+1)+":");
           char c = (char)sc.next().charAt(0);
           CharLib c1=new CharLib(c);
           Queuell.add(i, c1);
           }
        System.out.println();
    }
       
    
    public void hapustengah(){
        Queuell.remove(batas/2);
        batas-=1;
        System.out.println();
    }
    
    public void display1(){
        Iterator<CharLib> ii=Queuell.iterator();
        if(! ii.hasNext())
            System.out.println("Data is empty");
        else{
            while (ii.hasNext()){
                CharLib tempkar= ii.next();
                System.out.print(tempkar.getKarakter()+" ");
            }
            System.out.println();
        }
    }
    
    public void bagiDua() {
        for(int i = 0; i < batas/2; i++) {
                Queuelkiri.add(Queuell.get(i));
            }
            Iterator<CharLib> ikiri=Queuelkiri.iterator();
            if(! ikiri.hasNext()) {
                System.out.println("Queue LL kiri kosong");}
            else{
                System.out.print("Queue kiri ");
                while (ikiri.hasNext()){
                    CharLib tempkar= ikiri.next();
                    System.out.print(tempkar.getKarakter()+" ");
                }
            System.out.println();
            }
        if (this.batas % 2 == 0) {
            
            for(int i=this.batas/2; i< this.batas; i++) {
                Queuelkanan.add(Queuell.get(i));
            }
        } 
        else {
            for(int i=this.batas/2 + 1 ; i< this.batas; i++) {
                Queuelkanan.add(Queuell.get(i));
            }
        }
            Iterator<CharLib> ikanan=Queuelkanan.iterator();
            if(! ikanan.hasNext()) {
                System.out.println("Queue LL kanan kosong");}
            else{
                System.out.print("Queue kanan ");
                while (ikanan.hasNext()){
                    CharLib tempkar= ikanan.next();
                    System.out.print(tempkar.getKarakter()+" ");
                }
            System.out.println();
            }
        }     


}
