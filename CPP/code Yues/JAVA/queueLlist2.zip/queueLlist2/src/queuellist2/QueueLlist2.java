
package queuellist2;


public class QueueLlist2 {

    
    public static void main(String[] args) {
    Llistexplore l1=new Llistexplore();
    
    l1.masukLinkedList();
    l1.display1();
    l1.bagiDua();
    
    
}
}
