
package queuellist2;


 class CharLib {
    char karak;
    public CharLib(char karak){
        this.karak=karak;
    }
    
    public char getKarakter(){
        return this.karak;
    }
}
