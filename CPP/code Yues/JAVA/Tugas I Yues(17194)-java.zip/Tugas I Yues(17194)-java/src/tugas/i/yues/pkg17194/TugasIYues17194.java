/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas.i.yues.pkg17194;

import java.util.Scanner;


public class TugasIYues17194 {

    
    public static void main(String[] args) {
        // TODO code application logic here
     Scanner input = new Scanner (System.in);
       System.out.println("**Ramalan berdasarkan data kelahiran**");
       System.out.println("Format DDMYYYY");
       System.out.print("Masukkan tanggal lahir:");
       int tanggal_lahir = input.nextInt();
       
       System.out.print("Masukkan bulan lahir ke-:");
       int bulan_lahir = input.nextInt();
       
       System.out.print("Masukkan tahun lahir:");
       int tahun_lahir = input.nextInt();
       
       System.out.println("RAMALAN STYLE:");
       switch(tanggal_lahir){
           case 1:
           case 2:
               System.out.println("Leadership");break;
           case 3:
           case 4:
               System.out.println("Hardworker");break;
           case 5:
           case 6:
               System.out.println("Good ability");break;
           case 7:
           case 8:
               System.out.println("Romantis");break;
           case 9:
           case 10:
                System.out.println("Elegant");break;
           case 11:
           case 12:
               System.out.println("Dewasa");break;
           case 13:
           case 14:
               System.out.println("labil");break;
           case 15:
           case 16:
               System.out.println("Suram");break;
           case 17:
           case 18:
               System.out.println("Bertele-tele");break;
           case 19:
           case 20:
               System.out.println("Religius");break;
           case 21:
           case 22:
               System.out.println("Telmi");break;
           case 23:
           case 24:
               System.out.println("Anarkis");break;
           case 25:
           case 26:
               System.out.println("Berbakat, tapi malas");break;
           case 27:
           case 28:
               System.out.println("Hanya bermimpi");break;
           case 29:
           case 30:
               System.out.println("Swag");break;
       }
       System.out.println("RAMALAN PEKERJAAN:");
        switch(bulan_lahir){
            case 1 :
                System.out.println("Google staff");break;
            case 2:
                System.out.println("Android Dev");break;
            case 3:
            case 4:
                System.out.println("Data Scientist");break;
            case 5:
                System.out.println("Menteri kominfo");break;
            case 6:
                System.out.println("PNS bidang IT");break;
            case 7:
            case 8:
                System.out.println("Buka Warnet");break;
            case 9:
                System.out.println("Service komputer");break;
            case 10:
                System.out.println("Jual crack game bajakan");break;
            case 11:
                System.out.println("Tukang suntik lagu"); break;
            case 12:
                System.out.println("Buka start-up");break;
                    }
        System.out.println("RAMALAN RUMAH TANGGA:");
        if(tahun_lahir>=1990 && tahun_lahir<=1992){
            System.out.println("Talak 4");
        }
            else if (tahun_lahir>=1993 && tahun_lahir<=1995){
            System.out.println("banyak anak, banyak rezeki");
    }
            else if (tahun_lahir>=1996 && tahun_lahir<=1998){
            System.out.println("Sakinah,Mawadah,Warohmah");
    }
            else if(tahun_lahir>=1998){
            System.out.println("Poligami");
            }
            else if(tahun_lahir>=1950 && tahun_lahir<=1960){
            System.out.println("Langgeng");
    }
            else if(tahun_lahir>=1961 && tahun_lahir<=1980){
            System.out.println("Makmur,Sejahtera");
            }
            else if(tahun_lahir>=1981 && tahun_lahir<=1989){
             System.out.println("Banyak godaan setan");
            }
                  
    }
}
    

