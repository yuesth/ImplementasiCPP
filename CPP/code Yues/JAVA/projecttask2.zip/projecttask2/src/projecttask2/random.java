
package projecttask2;
import java.util.Random;


public class random {
    static Random r=new Random();
    static double[]arr;
    static float tampungarray;
    
    public static void tampilrandom(int ukuran){
        arr=new double[ukuran];
        for(int i=0;i<ukuran;i++){
            arr[i]=r.nextDouble()*4.00;
            arr[i]=Math.round(arr[i]*100)/100.0d;
            
            System.out.println("array ke-"+i+":"+arr[i]);
        }
    }
}
