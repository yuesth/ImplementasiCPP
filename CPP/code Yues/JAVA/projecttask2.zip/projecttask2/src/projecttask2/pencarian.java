/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecttask2;

/**
 *
 * @author mymac
 */
public class pencarian {
        static int found;
    
     public  static boolean binarysearch(double f,double a[]){
        int awal=0,akhir=(a.length-1);
        
        boolean b=false;
        
        while(awal<=akhir){
            int tengah=(awal+akhir)/2;
            
            if(f==a[tengah]){
               found=tengah; 
               b=true;
               break;
            }
            else if(f>a[tengah]){
                awal=tengah+1;
            }
            else{
                akhir=tengah-1;
            }
        }
        return b;
        
        
        }
}
