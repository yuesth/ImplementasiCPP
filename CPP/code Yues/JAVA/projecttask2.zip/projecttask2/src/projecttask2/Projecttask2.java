/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecttask2;
import java.util.Scanner;

public class Projecttask2 {
    static Scanner sc=new Scanner(System.in);
    static int input;
    static double find;
    static boolean hasil=false;
    
    public static void introduction(){
        System.out.println("*Selamat datang di program pencarian data dengan fungsi random*");
    }
    
    
    public static void main(String[] args) {
       introduction();
       System.out.print("Masukkan banyak data nilai IPK:");
       input =sc.nextInt();
       random.tampilrandom(input);
       pengurutan.selectionsort(input, random.arr);
       System.out.println("Masukkan data yang ingin dicari:");
       find=sc.nextDouble();
       hasil=pencarian.binarysearch(find,random.arr);
       if(hasil){
           System.out.println("data ditemukan pada indeks array ke-"+pencarian.found);
       }
       else{
           System.out.println("Data tidak ditemukan");
       }
       
       
    }
    
}
