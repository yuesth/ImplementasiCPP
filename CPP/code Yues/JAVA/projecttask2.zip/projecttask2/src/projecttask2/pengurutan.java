
package projecttask2;


public class pengurutan {
    static double temp;
    
    public static void selectionsort(int ukurann, double ar[]){
        for(int i=0;i<(ukurann-1);i++){
          int min=i;
          for(int j=i+1;j<ukurann;j++){
              if(ar[j]<ar[min])
              {
                  min=j;
              }
          }
          temp=ar[i];
          ar[i]=ar[min];
          ar[min]=temp; 
      }
        System.out.println("*Data sesudah diurut*");
        for(int k=0;k<ukurann;k++){
            System.out.println("array ke"+k+":"+ar[k]+" ");
        }
    } 
}
